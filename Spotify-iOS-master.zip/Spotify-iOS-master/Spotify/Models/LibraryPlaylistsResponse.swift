//
//  LibraryPlaylistsResponse.swift
//  Spotify
//
//  Created by Afraz Siddiqui on 2/21/21.
//

import Foundation

struct LibraryPlaylistsResponse: Codable {
    let items: [Playlist]
}
