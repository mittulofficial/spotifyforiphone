//
//  UserImage.swift
//  Spotify
//
//  Created by Afraz Siddiqui on 2/15/21.
//

import Foundation

struct APIImage: Codable {
    let url: String
}
