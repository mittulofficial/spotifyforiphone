//
//  AlbumCollectionViewCellViewModel.swift
//  Spotify
//
//  Created by Afraz Siddiqui on 2/19/21.
//

import Foundation

struct AlbumCollectionViewCellViewModel {
    let name: String
    let artistName: String
}
